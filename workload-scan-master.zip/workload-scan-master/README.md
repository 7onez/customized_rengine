# workload-scan

### How to run

- Build docker image
```
docker build -t workload_scan .
```
- Go inside docker image
```
docker run -it --rm workload_scan /bin/bash
```

- Add Env variables
```
export report_file_eod=eod.json
export report_file_surface=surface.json
export report_file_deep=deep.json
export folder_name=/opt
export target_ip=127.0.0.1
```

- Run Scan
```
python3 workload_scanner.py -all_scan true
```
